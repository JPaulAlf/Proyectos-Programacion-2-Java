
package capaInterfaz;

import capaInterfaz.FrmUniversidad;


public class PrincipalUniversidad {

   
    public static void main(String[] args) {
        FrmUniversidad frmUniversidad = new FrmUniversidad();
        frmUniversidad.setVisible(true);
        frmUniversidad.setLocationRelativeTo(null);
    }
    
}
